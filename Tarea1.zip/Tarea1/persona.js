const persona = { 
    nombre: "Ana", 
    edad: 25, 
    ciudad: "SPS" }

const { nombre, edad, ciudad } = persona

console.log(nombre)
console.log(edad)
console.log(ciudad)