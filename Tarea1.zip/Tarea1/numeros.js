const numeros = [5, 8, 12, 3, 7, 19, 1, 10, 2]

let mayor = numeros[0]

for (let i = 1; i < numeros.length; i++) {
    if (numeros[i] > mayor) {
        mayor = numeros[i]
    }
}

console.log("El número mayor es:"+ mayor)