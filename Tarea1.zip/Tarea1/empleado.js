const empleado = { 
    nombre: "Juan", 
    salario: 10000, 
    antiguedad: 6
};

if (empleado.antiguedad > 5) {
    empleado.salario  *=  1.10   // Incrementa el salario en un 10%
}else {
    console.log("La antigüedad es menor o igual a 5 años, no hay aumento de salario.")
}
  
  console.log(`Nombre: ${empleado.nombre}`)
  console.log(`Salario: ${empleado.salario}`)
  console.log(`Antigüedad: ${empleado.antiguedad}`)

