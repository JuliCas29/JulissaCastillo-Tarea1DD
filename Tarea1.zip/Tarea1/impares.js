const numeros = [5, 8, 12, 3, 7, 19, 1, 10, 2]

let sumaImpar = 0
let contador = 0

for (let i = 0; i < numeros.length; i++) {
    if (numeros[i] % 2 !== 0) { 
        sumaImpar+= numeros[i]
        contador++
    }
}

if (contador > 0) {
    let promedioImpares = sumaImpar / contador;
    console.log('El promedio de los números impares es:', promedioImpares)
} else {
    console.log('No hay números impares en la lista.')
}